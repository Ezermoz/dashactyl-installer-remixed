# dashactyl-installer
This is a simple script that allows you to do one command to fully install and configure Dashactyl.

# Installation
`curl -Lo install.sh https://raw.githubusercontent.com/J0shh/dashactyl-installer/main/install.sh`

`sudo bash install.sh`

# Feedback and Suggestions
Please send me a message on Disocrd, `_Josh_#0086` if you have any suggestions or feedback or leave them on the github page.
If you find any bugs or issues please make a report on the Issues tab on Github and I'll try my best to sort it.

# License
Github Project 'dashactyl-installer'                                    
By _Josh_#0086                                                                                            
                                                                           
This program is free software: you can redistribute it and/or modify    
it under the terms of the GNU General Public License as published by    
the Free Software Foundation, either version 3 of the License, or       
(at your option) any later version.                                     
                                                                           
This program is distributed in the hope that it will be useful,         
but WITHOUT ANY WARRANTY; without even the implied warranty of          
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           
GNU General Public License for more details.                            
                                                                           
You should have received a copy of the GNU General Public License       
along with this program.  If not, see <https://www.gnu.org/licenses/>.  
